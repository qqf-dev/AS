/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.ISTMdatabase;

/**
 *
 * @author dell
 */
public class Resource {
    
    private int resourceId;

    private int sectionId;

    private String resourceTit;

    private String resourceDescription;
    
    private String resourceData;

    public Resource(int resourceId, int sectionId, String resourceTit, String resourceDescription, String resourceData) {
        this.resourceId = resourceId;
        this.sectionId = sectionId;
        this.resourceTit = resourceTit;
        this.resourceDescription = resourceDescription;
        this.resourceData = resourceData;
    }

    public int getResourceId() {
        return resourceId;
    }

    public void setResourceId(int resourceId) {
        this.resourceId = resourceId;
    }

    public int getSectionId(){ return this.sectionId; }

    public void setSectionId(int sectionId){ this.sectionId = sectionId; }

    public String getResourceTit() {
        return resourceTit;
    }

    public void setResourceTit(String resourceTit) {
        this.resourceTit = resourceTit;
    }

    public String getResourceDescription() {
        return resourceDescription;
    }

    public void setResourceDescription(String resourceDescription) {
        this.resourceDescription = resourceDescription;
    }

    public String getResourceData() {
        return resourceData;
    }

    public void setResourceData(String resourceData) {
        this.resourceData = resourceData;
    }

    
}
