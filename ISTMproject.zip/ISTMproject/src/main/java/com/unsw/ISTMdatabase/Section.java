/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.ISTMdatabase;

/**
 *
 * @author dell
 */
public class Section {
    
    private int sectionId;

    private int moduleId;

    private String sectionName;

    private String sectionDescription;

    private int seqNo;

    public Section(int sectionId, int moduleId, String sectionName, String sectionDescription, int seqNo) {
        this.sectionId = sectionId;
        this.moduleId = moduleId;
        this.sectionName = sectionName;
        this.sectionDescription = sectionDescription;
        this.seqNo = seqNo;
    }

    public int getSectionId() {
        return sectionId;
    }

    public void setSectionId(int sectionId) {
        this.sectionId = sectionId;
    }

    public int getModuleId() {return moduleId; }

    public void setModuleId(int moduleId) { this.moduleId = moduleId; }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public String getSectionDescription() {
        return sectionDescription;
    }

    public void setSectionDescription(String sectionDescription) {
        this.sectionDescription = sectionDescription;
    }
    
    public int getSeqNo(){ return this.seqNo; }

    public void setSeqNo(int seqNo){ this.seqNo = seqNo; }
}
