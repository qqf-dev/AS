/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.ISTMdatabase;

/**
 *
 * @author dell
 */
public class ModuleLearningOutcome {
    
    private int mloId;

    private int moduleId;

    private String mloName;

    private String mloDescription;

    private int seqNo;

    public ModuleLearningOutcome(int mloId, int moduleId, String mloName, String mloDescription, int seqNo) {
        this.mloId = mloId;
        this.moduleId = moduleId;
        this.mloName = mloName;
        this.mloDescription = mloDescription;
        this.seqNo = seqNo;
    }

    public int getMloId() {
        return mloId;
    }

    public void setMloId(int mloId) {
        this.mloId = mloId;
    }

    public int getModuleId(){ return this.moduleId; }

    public void setModuleId(int moduleId){ this.moduleId = moduleId; }

    public String getMloName() {
        return mloName;
    }

    public void setMloName(String mloName) {
        this.mloName = mloName;
    }

    public String getMloDescription() {
        return mloDescription;
    }

    public void setMloDescription(String mloDescription) {
        this.mloDescription = mloDescription;
    }

    public int getSeqNo(){ return this.seqNo; }

    public void setSeqNo(int seqNo) {this.seqNo = seqNo;}
    
    
}
