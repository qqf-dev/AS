/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.ISTMcontroller;

import com.unsw.ISTMdatabase.CoursesHaveModules;
import com.unsw.ISTMdatabase.Database;
import com.unsw.ISTMdatabase.Course;
import com.unsw.ISTMdatabase.Module;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.io.IOException;
import java.sql.Array;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author dell
 */
public class CourseController {
    @FXML
    TableView<Course> courseView;

    @FXML
    TextField courseID;

    @FXML
    TextField courseName;

    @FXML
    TextField schoolName;

    @FXML
    TableColumn<Course, String> colCourseName;

    @FXML
    TableColumn<Course, String> colSchoolName;

    @FXML
    TableView<CoursesHaveModules> courseHasModuleView;

    @FXML
    TextField chmId;

    @FXML
    ChoiceBox<String> cbOfModule;

    @FXML
    TextField seqNo;

    @FXML
    TextField addCourseId;
    
    @FXML
    public void initialize() throws SQLException{
        colCourseName.setCellValueFactory(new PropertyValueFactory<>("courseName"));
        colSchoolName.setCellValueFactory(new PropertyValueFactory<>("schoolName"));

        colCourseName.setCellFactory(TextFieldTableCell.forTableColumn());
        colSchoolName.setCellFactory(TextFieldTableCell.forTableColumn());
        courseView.setEditable(true);

        colCourseName.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setCourseName(e.getNewValue());
            Course course = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateCourse(course);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        colSchoolName.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setSchoolName(e.getNewValue());
            Course course = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateCourse(course);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        ObservableList<Course> data = courseView.getItems();
        ArrayList<Course> course = Database.fetchAllCourses();
        data.addAll(course);
        courseView.setItems(data);

        initialChoiceBOx();

    }

    public void initialChoiceBOx() throws SQLException{
        ArrayList<Module> modules = Database.fetchAllModules();
        cbOfModule.getItems().clear();
        for(Module m : modules){
            cbOfModule.getItems().add(m.getModuleId() + "|" + m.getModuleName());
        }
    }

    @FXML
    public void addCourse() throws IOException, SQLException {
        int inputCourseId = Integer.parseInt(courseID.getText());
        String inputCourseName = courseName.getText();
        String inputSchoolName = schoolName.getText();
        Course course = new Course(inputCourseId, inputCourseName, inputSchoolName);
        Database.insertCourse(course);

        ObservableList<Course> observableList = courseView.getItems();
        observableList.add(course);
        courseView.setItems(observableList);

        courseID.clear();
        courseName.clear();
        schoolName.clear();
    }

    @FXML
    public void onCourseViewClicked() throws SQLException{
        Course course = courseView.getItems().get(courseView.getSelectionModel().getSelectedIndex());
        ObservableList<CoursesHaveModules> list = courseHasModuleView.getItems();
        list.clear();
        ArrayList<CoursesHaveModules> data = Database.fetchCourseHaveModules(course.getCourseId());
        list.addAll(data);
        courseHasModuleView.setItems(list);
    }

    @FXML
    public void addCourseModule() throws SQLException{
        int inputCHMId = Integer.parseInt(chmId.getText());
        int inputCourseId = Integer.parseInt(addCourseId.getText());
        int inputSeqNo = Integer.parseInt(seqNo.getText());
        String selModule = cbOfModule.getValue();
        int inputModuleId = Integer.parseInt(selModule.split("|")[0]);
        CoursesHaveModules obj = new CoursesHaveModules(inputCHMId, inputModuleId, inputCourseId, inputSeqNo);
        Database.insertCourseHaveModule(obj);
        courseHasModuleView.getItems().add(obj);
    }



}

