package com.unsw.ISTMcontroller;

import com.unsw.ISTMdatabase.ModuleLearningOutcome;
import com.unsw.ISTMdatabase.Database;
import com.unsw.ISTMdatabase.Module;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class OutcomeController {

    @FXML
    TableView<Module> moduleView;

    @FXML
    TableColumn<Module, String> colModuleName;

    @FXML
    TableColumn<Module, String> colModuleDes;

    @FXML
    TableView<ModuleLearningOutcome> outcomeView;

    @FXML
    TextField addMLOId;

    @FXML
    TextField addMLOModuleId;

    @FXML
    TextField addMLOName;

    @FXML
    TextField addMLODes;

    @FXML
    TextField addMLOSeqNo;

    @FXML
    public void initialize() throws SQLException{
        colModuleName.setCellValueFactory(new PropertyValueFactory<>("moduleName"));
        colModuleDes.setCellValueFactory(new PropertyValueFactory<>("moduleDescription"));

        colModuleName.setCellFactory(TextFieldTableCell.forTableColumn());
        colModuleDes.setCellFactory(TextFieldTableCell.forTableColumn());
        moduleView.setEditable(true);

        colModuleName.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setModuleName(e.getNewValue());
            Module module = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateModule(module);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        colModuleDes.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setModuleDescription(e.getNewValue());
            Module module = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateModule(module);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        ObservableList<Module> data = moduleView.getItems();
        ArrayList<Module> modules = Database.fetchAllModules();
        data.addAll(modules);
        moduleView.setItems(data);
    }

    @FXML
    public void onModuleViewClicked() throws SQLException{
        Module module = moduleView.getItems().get(moduleView.getSelectionModel().getSelectedIndex());
        ObservableList<ModuleLearningOutcome> sections = outcomeView.getItems();
        sections.clear();
        ArrayList<ModuleLearningOutcome> data = Database.fetchLearningOutcome(module.getModuleId());
        sections.addAll(data);
    }

    public void addMLO(ActionEvent event) throws SQLException{
        int inputMLOId = Integer.parseInt(addMLOId.getText());
        int inputModuleId = Integer.parseInt(addMLOModuleId.getText());
        String inputMLOName = addMLOName.getText();
        String inputMLODes = addMLODes.getText();
        int inputMLOSeqNo = Integer.parseInt(addMLOSeqNo.getText());
        ModuleLearningOutcome obj = new ModuleLearningOutcome(inputMLOId, inputModuleId, inputMLOName,
                inputMLODes, inputMLOSeqNo);
        Database.insertModuleLearningOutcome(obj);
        outcomeView.getItems().add(obj);
    }
}
