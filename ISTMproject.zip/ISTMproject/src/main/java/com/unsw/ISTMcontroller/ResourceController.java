package com.unsw.ISTMcontroller;

import com.unsw.ISTMdatabase.Database;
import com.unsw.ISTMdatabase.Resource;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.io.IOException;
import java.sql.Array;
import java.sql.SQLException;
import java.util.ArrayList;

public class ResourceController {

    @FXML
    TableView<Resource> resourceView;

    @FXML
    TextField resourceID;

    @FXML
    TextField sectionId;

    @FXML
    TextField resourceTit;

    @FXML
    TextField resourceDes;
    
    @FXML
    TextField resourceData;

    @FXML
    TableColumn<Resource, String> colSectionId;

    @FXML
    TableColumn<Resource, String> colResourceTit;

    @FXML
    TableColumn<Resource, String> colResourceDes;
    
    @FXML
    TableColumn<Resource, String> colResourceData;
    

    @FXML
    public void initialize() throws SQLException{
        colSectionId.setCellValueFactory(new PropertyValueFactory<>("sectionId"));
        colResourceTit.setCellValueFactory(new PropertyValueFactory<>("resourceTit"));
        colResourceDes.setCellValueFactory(new PropertyValueFactory<>("resourceDes"));
        colResourceData.setCellValueFactory(new PropertyValueFactory<>("resourceData"));

        colSectionId.setCellFactory(TextFieldTableCell.forTableColumn());
        colResourceTit.setCellFactory(TextFieldTableCell.forTableColumn());
        colResourceDes.setCellFactory(TextFieldTableCell.forTableColumn());
        colResourceData.setCellFactory(TextFieldTableCell.forTableColumn());
        resourceView.setEditable(true);

        colResourceTit.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setResourceTit(e.getNewValue());
            Resource resource = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateResource(resource);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        colResourceDes.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setResourceDescription(e.getNewValue());
            Resource resource = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateResource(resource);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });
        
        colResourceData.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setResourceDescription(e.getNewValue());
            Resource resource = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateResource(resource);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        ObservableList<Resource> data = resourceView.getItems();
        ArrayList<Resource> resources = Database.fetchAllResource();
        data.addAll(resources);
        resourceView.setItems(data);

    }

    @FXML
    public void addResource() throws IOException, SQLException {
        int inputResourceId = Integer.parseInt(resourceID.getText());
        int inputSectionId = Integer.parseInt(sectionId.getText());
        String inputResourceTit = resourceTit.getText();
        String inputResourceDes = resourceDes.getText();
        String inputResourceData = resourceData.getText();
        Resource resource = new Resource(inputResourceId,inputSectionId,inputResourceTit,
                inputResourceDes, inputResourceData);
        Database.insertResource(resource);

        ObservableList<Resource> observableList = resourceView.getItems();
        observableList.add(resource);
        resourceView.setItems(observableList);

        resourceID.clear();
        resourceTit.clear();
        resourceData.clear();
        resourceDes.clear();
    }



}