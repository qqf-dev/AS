package com.unsw.ISTMcontroller;

import java.io.IOException;

import com.unsw.ISTMdatabase.Database;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;

public class HomeController {

    @FXML
    TabPane tabPane;

    @FXML
    Tab aboutPage;

    @FXML
    Tab coursePage;

    @FXML
    Tab modulePage;

    @FXML
    Tab outcomePage;

    @FXML
    Tab archivedPage;

    @FXML
    public void initialize() throws IOException {
        aboutPage.setContent(new FXMLLoader(App.class.getResource("About.fxml")).load());
        coursePage.setContent(new FXMLLoader(App.class.getResource("course.fxml")).load());
        modulePage.setContent(new FXMLLoader(App.class.getResource("module.fxml")).load());
        outcomePage.setContent(new FXMLLoader(App.class.getResource("outcome.fxml")).load());
        Database.createTables();

    }

}
