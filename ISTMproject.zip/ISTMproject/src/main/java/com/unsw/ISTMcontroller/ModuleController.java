package com.unsw.ISTMcontroller;

import com.unsw.ISTMdatabase.Database;
import com.unsw.ISTMdatabase.Module;
import com.unsw.ISTMdatabase.Resource;
import com.unsw.ISTMdatabase.Section;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class ModuleController {

    @FXML
    TableView<Module> moduleView;

    @FXML
    TextField moduleID;

    @FXML
    TextField moduleName;

    @FXML
    TextField moduleDes;

    @FXML
    TableColumn<Module, String> colModuleName;

    @FXML
    TableColumn<Module, String> colModuleDes;

    @FXML
    TableView<Section> sectionView;

    @FXML
    TextField addSectionId;

    @FXML
    TextField addModuleId;

    @FXML
    TextField addSectionName;

    @FXML
    TextField addSectionDes;

    @FXML
    TextField addSectionSeqNo;

    @FXML
    TableView<Resource> resourceView;

    @FXML
    TextField addResourceId;

    @FXML
    TextField addResourceSectionId;

    @FXML
    TextField addResourceTitle;

    @FXML
    TextField addResourceDes;

    @FXML
    TextField addResourceData;

    @FXML
    public void initialize() throws SQLException{
        colModuleName.setCellValueFactory(new PropertyValueFactory<>("moduleName"));
        colModuleDes.setCellValueFactory(new PropertyValueFactory<>("moduleDescription"));

        colModuleName.setCellFactory(TextFieldTableCell.forTableColumn());
        colModuleDes.setCellFactory(TextFieldTableCell.forTableColumn());
        moduleView.setEditable(true);

        colModuleName.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setModuleName(e.getNewValue());
            Module module = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateModule(module);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        colModuleDes.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setModuleDescription(e.getNewValue());
            Module module = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try{
                Database.updateModule(module);
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        });

        ObservableList<Module> data = moduleView.getItems();
        ArrayList<Module> modules = Database.fetchAllModules();
        data.addAll(modules);
        moduleView.setItems(data);

    }

    @FXML
    public void addModule() throws IOException, SQLException {
        int inputModuleId = Integer.parseInt(moduleID.getText());
        String inputModuleName = moduleName.getText();
        String inputModuleDes = moduleDes.getText();
        Module module = new Module(inputModuleId, inputModuleName, inputModuleDes);
        Database.insertModule(module);

        ObservableList<Module> observableList = moduleView.getItems();
        observableList.add(module);
        moduleView.setItems(observableList);

        moduleID.clear();
        moduleName.clear();
        moduleDes.clear();
    }

    @FXML
    public void addResource(ActionEvent actionEvent) throws SQLException {
        int inputResourceId = Integer.parseInt(addResourceId.getText());
        int inputSectionId = Integer.parseInt(addResourceSectionId.getText());
        String inputResourceTitle = addResourceTitle.getText();
        String inputResourceDes = addResourceDes.getText();
        String inputResourceData = addResourceData.getText();
        Resource resource = new Resource(inputResourceId, inputSectionId, inputResourceTitle,
                inputResourceDes, inputResourceData);
        Database.insertResource(resource);
        resourceView.getItems().add(resource);
    }

    @FXML
    public void addSection(ActionEvent actionEvent) throws SQLException {
        int inputSectionId = Integer.parseInt(addSectionId.getText());
        int inputModuleId = Integer.parseInt(addModuleId.getText());
        String inputSectionName = addSectionName.getText();
        String inputSectionDes = addSectionDes.getText();
        int inputSeqNo = Integer.parseInt(addSectionSeqNo.getText());
        Section section = new Section(inputSectionId, inputModuleId, inputSectionName, inputSectionDes, inputSeqNo);
        Database.insertSection(section);
        sectionView.getItems().add(section);
    }

    @FXML
    public void onModuleViewClicked() throws SQLException{
        Module module = moduleView.getItems().get(moduleView.getSelectionModel().getSelectedIndex());
        ObservableList<Section> sections = sectionView.getItems();
        sections.clear();
        ArrayList<Section> data = Database.fetchModuleSection(module.getModuleId());
        sections.addAll(data);
    }

    @FXML
    public void onSectionViewClicked() throws  SQLException{
        Section section = sectionView.getItems().get(sectionView.getSelectionModel().getSelectedIndex());
        ObservableList<Resource> resources = resourceView.getItems();
        resources.clear();
        ArrayList<Resource> data = Database.fetchSectionResource(section.getSectionId());
        resources.addAll(data);
    }
}
