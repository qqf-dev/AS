package com.unsw.istmproject.database;

import java.sql.*;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;

public class Database {
  // Shove all our table create methods.
  // You'll need jdbc for this.

  public static Connection getConnection() throws SQLException{
      return DriverManager.getConnection("jdbc:sqlite:courseDatabase.db");
  }

  public static void insertModule(Module module) throws SQLException{
    try {
      Connection conn = getConnection();
      String sql = "INSERT INTO Module VALUES(?, ?, ?)";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, module.getModuleId());
      st.setString(2, module.getModuleName());
      st.setString(3, module.getModuleDescription());
      st.execute();
      st.close();
      conn.close();
    } catch (SQLException e){
      e.printStackTrace();
    }
  }

  public static void updateModule(Module module) throws SQLException{
    try{
      Connection conn = getConnection();
      String sql = "UPDATE Module SET MODULE_NAME = ? and MODULE_DESCRIPTION = ? WHERE MODULE_ID = ?";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setString(1, module.getModuleName());
      st.setString(2, module.getModuleDescription());
      st.setInt(3, module.getModuleId());
      st.execute();
      st.close();
      conn.close();
    }catch(SQLException e){
      e.printStackTrace();
    }
  }

  public static ArrayList<Module> fetchAllModules() throws SQLException{
      Connection conn = getConnection();
      String sql = "SELECT MODULE_ID, MODULE_NAME, MODULE_DESCRIPTION FROM Module";
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(sql);
      ArrayList<Module> list = new ArrayList<>();
      while(rs.next()){
        list.add(new Module(rs.getInt(1), rs.getString(2), rs.getString(3)));
      }
      return list;
  }
  
  public static void insertCourse(Course course) throws SQLException{
    try {
      Connection conn = getConnection();
      String sql = "INSERT INTO Course VALUES(?, ?, ?)";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, course.getCourseId());
      st.setString(2, course.getCourseName());
      st.setString(3, course.getSchoolName());
      st.execute();
      st.close();
      conn.close();
    } catch (SQLException e){
      e.printStackTrace();
    }
  }
  
  public static void updateCourse(Course course) throws SQLException{
    try{
      Connection conn = getConnection();
      String sql = "UPDATE Course SET COURSE_NAME = ? and SCHOOL_NAME = ? WHERE COURSE_ID = ?";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, course.getCourseId());
      st.setString(2, course.getCourseName());
      st.setString(3, course.getSchoolName());
      st.execute();
      st.close();
      conn.close();
    }catch(SQLException e){
      e.printStackTrace();
    }
  }
  
  public static ArrayList<Course> fetchAllCourses() throws SQLException{
      Connection conn = getConnection();
      String sql = "SELECT COURSE_ID, COURSE_NAME, SCHOOL_NAME FROM Course";
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(sql);
      ArrayList<Course> list = new ArrayList<>();
      while(rs.next()){
        list.add(new Course(rs.getInt(1), rs.getString(2), rs.getString(3)));
      }
      return list;
  }
  
  public static void insertResource(Resource resource) throws SQLException{
    try {
      Connection conn = getConnection();
      String sql = "INSERT INTO Resource VALUES(?, ?, ?,?, ?)";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, resource.getResourceId());
      st.setInt(2, resource.getSectionId());
      st.setString(3, resource.getResourceTit());
      st.setString(4, resource.getResourceDescription());
      st.setString(5, resource.getResourceData());
      st.execute();
      st.close();
      conn.close();
    } catch (SQLException e){
      e.printStackTrace();
    }
  }
  
  public static void updateResource(Resource resource) throws SQLException{
    try{
      Connection conn = getConnection();
      String sql = "UPDATE Course SET COURSE_NAME = ? and SCHOOL_NAME = ? WHERE COURSE_ID = ?";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, resource.getResourceId());
      st.setString(2, resource.getResourceTit());
      st.setString(3, resource.getResourceDescription());
      st.setString(4, resource.getResourceData());
      st.execute();
      st.close();
      conn.close();
    }catch(SQLException e){
      e.printStackTrace();
    }
  }
  
  public static ArrayList<Resource> fetchAllResource() throws SQLException{
      Connection conn = getConnection();
      String sql = "SELECT RESOURCE_ID, SECTION_ID, RESOURCE_TIT, RESOURCE_DESCRIPTION, RESOURCE_DATA FROM Course";
      Statement st = conn.createStatement();
      ResultSet rs = st.executeQuery(sql);
      ArrayList<Resource> list = new ArrayList<>();
      while(rs.next()){
        list.add(new Resource(rs.getInt(1), rs.getInt(2),
                rs.getString(2), rs.getString(3),rs.getString(4)));
      }
      return list;
  }

  public static ArrayList<CoursesHaveModules> fetchCourseHaveModules(int courseId) throws SQLException{
      Connection conn = getConnection();
      String sql = "SELECT CHM_ID, COURSE_ID, MODULE_ID, SEQUENCE_NO FROM CoursesHaveModules WHERE COURSE_ID = ?";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, courseId);
      ResultSet rs = st.executeQuery();
      ArrayList<CoursesHaveModules> list = new ArrayList<>();
      while(rs.next()){
        list.add(new CoursesHaveModules(rs.getInt(1), rs.getInt(2), rs.getInt(3),
                rs.getInt(4)));
      }
      st.close();
      conn.close();
      return list;
  }

  public static void insertCourseHaveModule(CoursesHaveModules obj) throws SQLException{
    Connection conn = getConnection();
    String sql = "INSERT INTO CoursesHaveModules(CHM_ID, COURSE_ID, MODULE_ID, SEQUENCE_NO) VALUES(?, ?, ?, ?)";
    PreparedStatement st = conn.prepareStatement(sql);
    st.setInt(1, obj.getChmId());
    st.setInt(2, obj.getCourseId());
    st.setInt(3, obj.getModuleId());
    st.setInt(4, obj.getSequenceNo());
    st.execute();
    st.close();
    conn.close();
  }

  public static void insertSection(Section section) throws  SQLException{
      Connection conn = getConnection();
      String sql = "INSERT INTO Section(SECTION_ID, MODULE_ID, SECTION_NAME, SECTION_DESCRIPTION, SEQUENCE_NO) VALUES(?, ?, ?,?,?)";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, section.getSectionId());
      st.setInt(2, section.getModuleId());
      st.setString(3, section.getSectionName());
      st.setString(4, section.getSectionDescription());
      st.setInt(5, section.getSeqNo());
      st.execute();
      st.close();
      conn.close();
  }

  public static ArrayList<Section> fetchModuleSection(int moduleId) throws  SQLException{
      Connection conn = getConnection();
      String sql = "SELECT SECTION_ID, MODULE_ID, SECTION_NAME, SECTION_DESCRIPTION, SEQUENCE_NO FROM Section WHERE MODULE_ID = ?";
      PreparedStatement st = conn.prepareStatement(sql);
      st.setInt(1, moduleId);
      ResultSet rs = st.executeQuery();
      ArrayList<Section> sections = new ArrayList<>();
      while(rs.next()){
        sections.add(new Section(rs.getInt(1), rs.getInt(2), rs.getString(3),
                rs.getString(4), rs.getInt(5)));
      }
      return sections;
  }

  public static ArrayList<Resource> fetchSectionResource(int sectionId) throws  SQLException{
    Connection conn = getConnection();
    String sql = "SELECT RESOURCE_ID, SECTION_ID, RESOURCE_TITLE, RESOURCE_DESCRIPTION, RESOURCE_DATA FROM Resource WHERE SECTION_ID = ?";
    PreparedStatement st = conn.prepareStatement(sql);
    st.setInt(1, sectionId);
    ResultSet rs = st.executeQuery();
    ArrayList<Resource> resources = new ArrayList<>();
    while(rs.next()){
      resources.add(new Resource(rs.getInt(1), rs.getInt(2), rs.getString(3),
              rs.getString(4), rs.getString(5)));
    }
    return resources;
  }

  public static ArrayList<ModuleLearningOutcome> fetchLearningOutcome(int moduleId) throws SQLException{
    Connection conn = getConnection();
    String sql = "SELECT MLO_ID, MODULE_ID, MLO_NAME, MLO_DESCRIPTION, SEQUENCE_NO FROM ModuleLearningOutcomes WHERE MODULE_ID = ?";
    PreparedStatement st = conn.prepareStatement(sql);
    st.setInt(1, moduleId);
    ResultSet rs = st.executeQuery();
    ArrayList<ModuleLearningOutcome> list = new ArrayList<>();
    while(rs.next()){
      list.add(new ModuleLearningOutcome(rs.getInt(1), rs.getInt(2),
              rs.getString(3), rs.getString(4), rs.getInt(5)));
    }
    return list;
  }

  public static void insertModuleLearningOutcome(ModuleLearningOutcome obj) throws SQLException{
    Connection conn = getConnection();
    String sql = "INSERT INTO ModuleLearningOutcomes(MLO_ID, MODULE_ID, MLO_NAME, MLO_DESCRIPTION, SEQUENCE_NO) VALUES (?,?,?,?,?)";
    PreparedStatement st = conn.prepareStatement(sql);
    st.setInt(1, obj.getMloId());
    st.setInt(2, obj.getModuleId());
    st.setString(3, obj.getMloName());
    st.setString(4, obj.getMloDescription());
    st.setInt(5, obj.getSeqNo());
    st.execute();
    st.close();
    conn.close();
  }
  
  public static void deleteModuleLearningOutcome(ModuleLearningOutcome obj) throws SQLException {
        Connection conn = getConnection();
        String sql = "DELETE FROM `ModuleLearningOutcomes` WHERE MLO_ID = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, obj.getMloId());
        st.execute();
        st.close();
        conn.close();
    }

  public void insert(String query) throws SQLException {
    Statement stmt = null;
    try {
      Connection conn = getConnection();
      stmt = conn.createStatement();
      stmt.executeUpdate(query);
      stmt.close();
      conn.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public static void createTables() {
    createCourse();
    createModule();
    createCourseHaveModules();
    createModuleLearningOutcomes();
    createSection();
    createResource();
  }

  public static void createModule() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS Module "
              + "(MODULE_ID  INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "MODULE_NAME VARCHAR(256) NOT NULL,"
              + "MODULE_DESCRIPTION VARCHAR(1024) NOT NULL "
              + ");";
      stmt.execute(query);
      stmt.close();
      conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }

  }

  public static void createResource() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS Resource "
              + "(RESOURCE_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "SECTION_ID INTEGER, "
              + "RESOURCE_TITLE VARCHAR(256) NOT NULL, "
              + "RESOURCE_DESCRIPTION TEXT NOT NULL, "
              + "RESOURCE_DATA TEXT NOT NULL, "
              + "FOREIGN KEY (SECTION_ID) REFERENCES Section (SECTION_ID) "
              + ");";

      stmt.execute(query);
      stmt.close();
      conn.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public static void createSection() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS Section "
              + "(SECTION_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "MODULE_ID INTEGER, "
              + "SECTION_NAME VARCHAR(256) NOT NULL, "
              + "SECTION_DESCRIPTION TEXT NOT NULL, "
              + "SEQUENCE_NO INTEGER NOT NULL, "
              + "FOREIGN KEY (MODULE_ID) REFERENCES Module (MODULE_ID) "
              + ");";

      stmt.execute(query);
      stmt.close();
      conn.close();
    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  public static void createCourse() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS Course "
              + "(COURSE_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "COURSE_NAME VARCHAR(256) NOT NULL,"
              + "SCHOOL_NAME VARCHAR(256) NOT NULL "
              + ");";
      stmt.execute(query);
      stmt.close();
      conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }

  }

  public static void createCourseHaveModules() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS CoursesHaveModules "
              + "(CHM_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "MODULE_ID INTEGER, "
              + "COURSE_ID INTEGER, "
              + "SEQUENCE_NO INTEGER NOT NULL,"
              + "FOREIGN KEY (MODULE_ID) REFERENCES Module (MODULE_ID), "
              + "FOREIGN KEY (COURSE_ID) REFERENCES Course (COURSE_ID) "
              + ");";
      stmt.execute(query);
      stmt.close();
      conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }

  }

  public static void createModuleLearningOutcomes() {
    try {
      Connection conn = getConnection();
      Statement stmt = conn.createStatement();
      String query = "CREATE TABLE IF NOT EXISTS ModuleLearningOutcomes"
              + "(MLO_ID INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
              + "MODULE_ID INTEGER, "
              + "MLO_NAME VARCHAR(256) NOT NULL,"
              + "MLO_DESCRIPTION TEXT NOT NULL, "
              + "SEQUENCE_NO TEXT NOT NULL,"
              + "FOREIGN KEY (MODULE_ID) REFERENCES Module (MODULE_ID) "
              + ");";
      stmt.execute(query);
      stmt.close();
      conn.close();

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }
}
