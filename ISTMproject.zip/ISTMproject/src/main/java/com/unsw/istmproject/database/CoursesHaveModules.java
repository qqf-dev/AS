/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.unsw.istmproject.database;

/**
 *
 * @author dell
 */
public class CoursesHaveModules {
    
    private int chmId;

    private int moduleId;

    private int courseId;

    private int sequenceNo;

    public CoursesHaveModules(int chmId, int moduleId, int courseId, int sequenceNo) {
        this.chmId = chmId;
        this.moduleId = moduleId;
        this.courseId = courseId;
        this.sequenceNo = sequenceNo;
    }

    public int getChmId() {
        return chmId;
    }

    public void setChmId(int chmId) {
        this.chmId = chmId;
    }

    public int getModuleId(){ return this.moduleId; }

    public void setModuleId(int moduleId){ this.moduleId = moduleId; }

    public int getCourseId(){ return this.courseId; }

    public void setCourseId(int courseId){this.courseId = courseId; }

    public int getSequenceNo() {
        return sequenceNo;
    }

    public void setSequenceNo(int sequenceNo) {
        this.sequenceNo = sequenceNo;
    }

    
}
