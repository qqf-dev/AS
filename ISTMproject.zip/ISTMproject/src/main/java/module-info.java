module ISTMproject {
    requires javafx.baseEmpty;
    requires javafx.base;
    requires javafx.fxml;
    requires javafx.controlsEmpty;
    requires javafx.controls;
    requires javafx.graphicsEmpty;
    requires javafx.graphics;
    requires java.sql;

    opens com.unsw.istmproject.controllers to javafx.fxml, javafx.graphics;
    opens com.unsw.istmproject.database to javafx.base;
}